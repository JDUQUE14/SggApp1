﻿namespace SggApp.DAL;

public class Class1
{

}
