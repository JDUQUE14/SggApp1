﻿namespace SggApp.BLL;

public class Class1
{

}
